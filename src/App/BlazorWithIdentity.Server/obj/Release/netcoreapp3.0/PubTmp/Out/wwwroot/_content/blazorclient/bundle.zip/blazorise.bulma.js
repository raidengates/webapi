if (!window.blazoriseBulma) {
    window.blazoriseBulma = {};
}

window.blazoriseBulma = {
    activateDatePicker: (elementId) => {
        return true;
    }
};
